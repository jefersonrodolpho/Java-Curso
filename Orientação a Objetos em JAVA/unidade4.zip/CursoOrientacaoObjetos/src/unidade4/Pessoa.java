package unidade4;

public abstract class Pessoa {
	
	protected String primeiroNome;
	protected String ultimoNome;
	
	public abstract void exibirInformacoes();

}
