package unidade5;

public record Curso(int idcurso, String nome, String formarealizacao, String ofertante, double valor) {

}
