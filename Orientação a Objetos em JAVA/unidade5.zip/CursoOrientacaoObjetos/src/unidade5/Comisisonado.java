package unidade5;

public final class Comisisonado extends ServidorPublico {

}
