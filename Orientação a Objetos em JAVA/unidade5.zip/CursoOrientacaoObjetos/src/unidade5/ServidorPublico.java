package unidade5;

public sealed class ServidorPublico permits Estatutario, Comisisonado, Temporario{

}
