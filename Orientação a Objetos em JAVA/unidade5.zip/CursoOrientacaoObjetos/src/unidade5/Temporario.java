package unidade5;

public final class Temporario extends ServidorPublico {

}
