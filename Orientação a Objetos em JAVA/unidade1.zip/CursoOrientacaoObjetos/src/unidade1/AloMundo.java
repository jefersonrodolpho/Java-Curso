package unidade1;

import javax.swing.JOptionPane;
/*********************/
public class AloMundo 
/*********************/
{  //Início da Classe
   
   //Atributos
   //Métodos	

	/*************************************/
	public static void main(String[] args) { //Início do Método
	/*************************************/
		System.out.println("Alo Mundo!!!");
		JOptionPane.showMessageDialog(null, "Alo Mundo!!!");
		
	} //Fim do Método

} //Fim da Classe
